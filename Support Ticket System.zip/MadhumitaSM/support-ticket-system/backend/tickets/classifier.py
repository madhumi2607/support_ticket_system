"""
LLM Classification Service

Supports Anthropic (Claude), OpenAI (GPT), and Google (Gemini).
Set LLM_PROVIDER env var to: anthropic | openai | google
Set LLM_API_KEY env var to your API key.

Prompt is designed to return strict JSON with category + priority.
"""

import os
import json
import logging

logger = logging.getLogger(__name__)

PROMPT_TEMPLATE = """You are a support ticket classifier for a software company.

Given the following support ticket description, classify it into:
1. category: one of [billing, technical, account, general]
2. priority: one of [low, medium, high, critical]

Guidelines:
- billing: payment issues, invoices, subscriptions, refunds, charges
- technical: bugs, errors, crashes, performance, integration, API issues
- account: login, password, access, permissions, profile, 2FA
- general: feature requests, questions, feedback, or anything else

Priority guidelines:
- critical: complete service outage, data loss, security breach, cannot use product at all
- high: major feature broken, significant impact on workflow, many users affected
- medium: partial issue, workaround exists, moderate impact
- low: minor inconvenience, cosmetic issue, question, feature request

Respond ONLY with valid JSON in this exact format:
{{"suggested_category": "<category>", "suggested_priority": "<priority>"}}

Ticket description:
{description}"""


def classify_ticket(description: str) -> dict:
    """
    Classify a ticket description using an LLM.
    Returns dict with suggested_category and suggested_priority.
    Falls back to defaults on any error.
    """
    provider = os.environ.get("LLM_PROVIDER", "anthropic").lower()
    api_key = os.environ.get("LLM_API_KEY", "")

    if not api_key:
        logger.warning("LLM_API_KEY not set, skipping classification")
        return _fallback()

    prompt = PROMPT_TEMPLATE.format(description=description)

    try:
        if provider == "anthropic":
            return _classify_anthropic(api_key, prompt)
        elif provider == "openai":
            return _classify_openai(api_key, prompt)
        elif provider == "google":
            return _classify_google(api_key, prompt)
        else:
            logger.warning(f"Unknown LLM_PROVIDER: {provider}")
            return _fallback()
    except Exception as e:
        logger.error(f"LLM classification failed: {e}")
        return _fallback()


def _parse_response(text: str) -> dict:
    """Parse JSON from LLM response text."""
    text = text.strip()
    # Find JSON object in response
    start = text.find("{")
    end = text.rfind("}") + 1
    if start == -1 or end == 0:
        raise ValueError("No JSON found in response")
    data = json.loads(text[start:end])

    valid_categories = {"billing", "technical", "account", "general"}
    valid_priorities = {"low", "medium", "high", "critical"}

    category = data.get("suggested_category", "").lower()
    priority = data.get("suggested_priority", "").lower()

    if category not in valid_categories or priority not in valid_priorities:
        raise ValueError(f"Invalid classification values: {data}")

    return {"suggested_category": category, "suggested_priority": priority}


def _classify_anthropic(api_key: str, prompt: str) -> dict:
    import anthropic
    client = anthropic.Anthropic(api_key=api_key)
    message = client.messages.create(
        model="claude-3-haiku-20240307",
        max_tokens=100,
        messages=[{"role": "user", "content": prompt}],
    )
    return _parse_response(message.content[0].text)


def _classify_openai(api_key: str, prompt: str) -> dict:
    from openai import OpenAI
    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        max_tokens=100,
        messages=[{"role": "user", "content": prompt}],
    )
    return _parse_response(response.choices[0].message.content)


def _classify_google(api_key: str, prompt: str) -> dict:
    import google.generativeai as genai
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel("gemini-pro")
    response = model.generate_content(prompt)
    return _parse_response(response.text)


def _fallback() -> dict:
    return {"suggested_category": None, "suggested_priority": None}
