import React, { useState, useEffect, useCallback } from "react";
import { api } from "./api/client";
import TicketForm from "./components/TicketForm";
import TicketList from "./components/TicketList";
import FilterBar from "./components/FilterBar";
import StatsDashboard from "./components/StatsDashboard";
import "./App.css";

export default function App() {
  const [tickets, setTickets] = useState([]);
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({ search: "", category: "", priority: "", status: "" });
  const [activeTab, setActiveTab] = useState("tickets");
  const [loading, setLoading] = useState(true);

  const fetchTickets = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.getTickets(filters);
      setTickets(data);
    } catch {
      console.error("Failed to load tickets");
    } finally {
      setLoading(false);
    }
  }, [filters]);

  const fetchStats = useCallback(async () => {
    try {
      const data = await api.getStats();
      setStats(data);
    } catch {
      console.error("Failed to load stats");
    }
  }, []);

  useEffect(() => { fetchTickets(); }, [fetchTickets]);
  useEffect(() => { fetchStats(); }, [fetchStats]);

  const handleCreated = (ticket) => {
    setTickets((prev) => [ticket, ...prev]);
    fetchStats();
  };

  const handleUpdated = (updated) => {
    setTickets((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
    fetchStats();
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-icon">◈</span>
            <span className="logo-text">SupportDesk</span>
          </div>
          <nav className="tabs">
            <button
              className={activeTab === "tickets" ? "tab active" : "tab"}
              onClick={() => setActiveTab("tickets")}
            >
              Tickets
            </button>
            <button
              className={activeTab === "new" ? "tab active" : "tab"}
              onClick={() => setActiveTab("new")}
            >
              + New
            </button>
            <button
              className={activeTab === "stats" ? "tab active" : "tab"}
              onClick={() => setActiveTab("stats")}
            >
              Stats
            </button>
          </nav>
        </div>
      </header>

      <main className="app-main">
        {activeTab === "new" && (
          <TicketForm
            onCreated={(t) => {
              handleCreated(t);
              setActiveTab("tickets");
            }}
          />
        )}

        {activeTab === "tickets" && (
          <div className="tickets-section">
            <FilterBar filters={filters} onChange={setFilters} />
            {loading ? (
              <div className="loading">Loading…</div>
            ) : (
              <TicketList tickets={tickets} onUpdated={handleUpdated} />
            )}
          </div>
        )}

        {activeTab === "stats" && <StatsDashboard stats={stats} />}
      </main>
    </div>
  );
}
