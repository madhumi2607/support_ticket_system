import React, { useState, useRef } from "react";
import { api } from "../api/client";

const CATEGORIES = ["billing", "technical", "account", "general"];
const PRIORITIES = ["low", "medium", "high", "critical"];

export default function TicketForm({ onCreated }) {
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    priority: "",
  });
  const [classifying, setClassifying] = useState(false);
  const [suggestion, setSuggestion] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const classifyTimeout = useRef(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));

    if (name === "description") {
      clearTimeout(classifyTimeout.current);
      if (value.trim().length > 20) {
        classifyTimeout.current = setTimeout(() => runClassify(value), 800);
      }
    }
  };

  const runClassify = async (description) => {
    setClassifying(true);
    try {
      const result = await api.classify(description);
      if (result.suggested_category && result.suggested_priority) {
        setSuggestion(result);
        setForm((f) => ({
          ...f,
          category: result.suggested_category,
          priority: result.suggested_priority,
        }));
      }
    } catch {
      // Graceful failure — user can still manually select
    } finally {
      setClassifying(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const ticket = await api.createTicket(form);
      setSuccess(true);
      setForm({ title: "", description: "", category: "", priority: "" });
      setSuggestion(null);
      setTimeout(() => setSuccess(false), 3000);
      onCreated(ticket);
    } catch (err) {
      setError(err.data ? JSON.stringify(err.data) : "Submission failed");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form className="ticket-form" onSubmit={handleSubmit}>
      <h2>Submit a Ticket</h2>

      <label>
        Title <span className="req">*</span>
        <input
          name="title"
          value={form.title}
          onChange={handleChange}
          maxLength={200}
          required
          placeholder="Brief summary of your issue"
        />
      </label>

      <label>
        Description <span className="req">*</span>
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          required
          rows={4}
          placeholder="Describe your issue in detail…"
        />
        {classifying && (
          <span className="classify-hint">⟳ AI is analyzing your description…</span>
        )}
        {suggestion && !classifying && (
          <span className="classify-hint ok">
            ✦ AI suggested: <strong>{suggestion.suggested_category}</strong> /{" "}
            <strong>{suggestion.suggested_priority}</strong>
          </span>
        )}
      </label>

      <div className="form-row">
        <label>
          Category <span className="req">*</span>
          <select
            name="category"
            value={form.category}
            onChange={handleChange}
            required
          >
            <option value="">Select…</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>

        <label>
          Priority <span className="req">*</span>
          <select
            name="priority"
            value={form.priority}
            onChange={handleChange}
            required
          >
            <option value="">Select…</option>
            {PRIORITIES.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </label>
      </div>

      {error && <div className="form-error">{error}</div>}
      {success && <div className="form-success">✓ Ticket submitted!</div>}

      <button type="submit" disabled={submitting || classifying}>
        {submitting ? "Submitting…" : "Submit Ticket"}
      </button>
    </form>
  );
}
