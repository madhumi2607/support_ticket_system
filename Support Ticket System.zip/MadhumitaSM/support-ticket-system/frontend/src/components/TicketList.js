import React, { useState } from "react";
import { api } from "../api/client";

const PRIORITY_BADGE = {
  low: "#4ade80",
  medium: "#facc15",
  high: "#fb923c",
  critical: "#f87171",
};

const STATUS_FLOW = {
  open: "in_progress",
  in_progress: "resolved",
  resolved: "closed",
  closed: null,
};

const STATUS_LABEL = {
  open: "→ Start",
  in_progress: "→ Resolve",
  resolved: "→ Close",
  closed: null,
};

function truncate(str, n = 120) {
  return str.length > n ? str.slice(0, n) + "…" : str;
}

function formatDate(iso) {
  return new Date(iso).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function TicketList({ tickets, onUpdated }) {
  const [updating, setUpdating] = useState(null);

  const advanceStatus = async (ticket) => {
    const next = STATUS_FLOW[ticket.status];
    if (!next) return;
    setUpdating(ticket.id);
    try {
      const updated = await api.patchTicket(ticket.id, { status: next });
      onUpdated(updated);
    } catch {
      alert("Failed to update ticket");
    } finally {
      setUpdating(null);
    }
  };

  if (tickets.length === 0) {
    return <div className="empty-state">No tickets found.</div>;
  }

  return (
    <div className="ticket-list">
      {tickets.map((t) => (
        <div key={t.id} className="ticket-card">
          <div className="ticket-header">
            <div className="ticket-meta">
              <span
                className="badge priority-badge"
                style={{ background: PRIORITY_BADGE[t.priority] }}
              >
                {t.priority}
              </span>
              <span className="badge category-badge">{t.category}</span>
              <span className={`badge status-badge status-${t.status}`}>
                {t.status.replace("_", " ")}
              </span>
            </div>
            <span className="ticket-date">{formatDate(t.created_at)}</span>
          </div>
          <h3 className="ticket-title">{t.title}</h3>
          <p className="ticket-desc">{truncate(t.description)}</p>
          <div className="ticket-footer">
            <span className="ticket-id">#{t.id}</span>
            {STATUS_LABEL[t.status] && (
              <button
                className="status-btn"
                onClick={() => advanceStatus(t)}
                disabled={updating === t.id}
              >
                {updating === t.id ? "…" : STATUS_LABEL[t.status]}
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
