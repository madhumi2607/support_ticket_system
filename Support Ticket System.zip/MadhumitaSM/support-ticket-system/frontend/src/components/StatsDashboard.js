import React from "react";

const PRIORITY_COLORS = {
  low: "#4ade80",
  medium: "#facc15",
  high: "#fb923c",
  critical: "#f87171",
};

const CATEGORY_COLORS = {
  billing: "#60a5fa",
  technical: "#a78bfa",
  account: "#34d399",
  general: "#94a3b8",
};

export default function StatsDashboard({ stats }) {
  if (!stats) return <div className="stats-loading">Loading stats…</div>;

  const maxPriority = Math.max(...Object.values(stats.priority_breakdown), 1);
  const maxCategory = Math.max(...Object.values(stats.category_breakdown), 1);

  return (
    <div className="stats-dashboard">
      <div className="stats-summary">
        <div className="stat-card">
          <span className="stat-number">{stats.total_tickets}</span>
          <span className="stat-label">Total Tickets</span>
        </div>
        <div className="stat-card highlight">
          <span className="stat-number">{stats.open_tickets}</span>
          <span className="stat-label">Open</span>
        </div>
        <div className="stat-card">
          <span className="stat-number">{stats.avg_tickets_per_day}</span>
          <span className="stat-label">Avg / Day</span>
        </div>
      </div>

      <div className="stats-breakdowns">
        <div className="breakdown">
          <h4>BY PRIORITY</h4>
          {Object.entries(stats.priority_breakdown).map(([k, v]) => (
            <div key={k} className="bar-row">
              <span className="bar-label">{k}</span>
              <div className="bar-track">
                <div
                  className="bar-fill"
                  style={{
                    width: `${(v / maxPriority) * 100}%`,
                    background: PRIORITY_COLORS[k],
                  }}
                />
              </div>
              <span className="bar-count">{v}</span>
            </div>
          ))}
        </div>

        <div className="breakdown">
          <h4>BY CATEGORY</h4>
          {Object.entries(stats.category_breakdown).map(([k, v]) => (
            <div key={k} className="bar-row">
              <span className="bar-label">{k}</span>
              <div className="bar-track">
                <div
                  className="bar-fill"
                  style={{
                    width: `${(v / maxCategory) * 100}%`,
                    background: CATEGORY_COLORS[k],
                  }}
                />
              </div>
              <span className="bar-count">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
